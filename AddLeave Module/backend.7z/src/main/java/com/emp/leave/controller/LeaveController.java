package com.emp.leave.controller;
import java.util.List;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.emp.leave.exception.ResourceNotFoundException;
import com.emp.leave.model.Leave;
import com.emp.leave.repository.LeaveRepository;


@CrossOrigin(origins ="*")
@RestController
@RequestMapping("/api/v1")
public class LeaveController {
	
	@Autowired
	private LeaveRepository leaveRepository;
	
	//get all Employees
	@GetMapping("/leaves")
	public List<Leave> getAllEmployees(){
		return leaveRepository.findAll();
	}
     @PostMapping("/leaves")
	public Leave createL(@RequestBody Leave leave) {
		return  leaveRepository.save(leave);
		
	}
     
     @DeleteMapping("/leaves/{empId}")
 	public ResponseEntity<Map<String, Boolean>> deleteLeave(@PathVariable Long empId){
 		Leave leave = leaveRepository.findById(empId)
 				.orElseThrow(() -> new ResourceNotFoundException("Leave not exist with id :" + empId));
 		
 		leaveRepository.delete(leave);
 		Map<String, Boolean> response = new HashMap<String, Boolean>();
 		response.put("deleted", Boolean.TRUE);
 		return ResponseEntity.ok(response);
 	}
}
