package com.Attendance.spring.controller;

import java.util.List;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.Attendance.spring.exception.ResourceNotFoundException;
import com.Attendance.spring.model.Attendance;
import com.Attendance.spring.repository.AttendanceRepository;


@CrossOrigin(origins ="*")
@RestController
@RequestMapping("/api/v1")
public class AttendanceController {
	
	@Autowired
	private AttendanceRepository attendanceRepository;
	
	//get all Employees
	@GetMapping("/employees")
	public List<Attendance> getAllEmployees(){
		return attendanceRepository.findAll();
	}
     @PostMapping("/employees")
	public Attendance createAttendance(@RequestBody Attendance attendance) {
		return  attendanceRepository.save(attendance);
		
	}
     
     @DeleteMapping("/employees/{empId}")
 	public ResponseEntity<Map<String, Boolean>> deleteEmployee(@PathVariable Long empId){
 		Attendance employee = attendanceRepository.findById(empId)
 				.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + empId));
 		
 		attendanceRepository.delete(employee);
 		Map<String, Boolean> response = new HashMap<>();
 		response.put("deleted", Boolean.TRUE);
 		return ResponseEntity.ok(response);
 	}
}
