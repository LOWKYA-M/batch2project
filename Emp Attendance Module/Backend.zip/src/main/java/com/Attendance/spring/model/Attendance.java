package com.Attendance.spring.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employees")
public class Attendance {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
  private long empId;
	@Column(name = "Date")
	private String Date;
	@Column(name = "Status")
  private String Status;
  
  public Attendance() {
	  
  }
public Attendance(String Date, String Status) {
	super();
	this.Date = Date;
	this.Status = Status;
}
public long getEmpId() {
	return empId;
}
public void setEmpId(long empId) {
	this.empId = empId;
}
public String getDate() {
	return Date;
}
public void setDate(String date) {
	Date = date;
}
public String getStatus() {
	return Status;
}
public void setStatus(String status) {
	Status = status;
}
  
  
}
