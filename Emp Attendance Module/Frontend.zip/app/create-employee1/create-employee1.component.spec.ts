import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateEmployee1Component } from './create-employee1.component';

describe('CreateEmployee1Component', () => {
  let component: CreateEmployee1Component;
  let fixture: ComponentFixture<CreateEmployee1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateEmployee1Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateEmployee1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
