export class Employee {
    empId:number;
    date:string;
    status:string;
}
