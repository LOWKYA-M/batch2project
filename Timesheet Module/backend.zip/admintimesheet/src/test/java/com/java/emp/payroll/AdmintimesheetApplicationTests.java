package com.java.emp.payroll;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdmintimesheetApplicationTests {

	@Test
	void contextLoads() {
	}

}
