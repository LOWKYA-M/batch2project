import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateTimesheetComponent } from './create-timesheet/create-timesheet.component';
import { TimesheetListComponent } from './timesheet-list/timesheet-list.component';
import { UpdateTimesheetComponent } from './update-timesheet/update-timesheet.component';

const routes: Routes = [
  {path: 'timesheets', component: TimesheetListComponent},
  {path: 'create-timesheet',component: CreateTimesheetComponent},
  {path: '', redirectTo: 'timesheets', pathMatch: 'full'},
  {path: 'update-timesheet/:empId',component: UpdateTimesheetComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
