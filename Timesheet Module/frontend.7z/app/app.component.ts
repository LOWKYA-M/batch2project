import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Timesheet } from './timesheet';
import { TimesheetService } from './timesheet.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Timesheet';
  timesheet: Timesheet[];
  constructor (private timesheetService: TimesheetService ,
    private router: Router){}
    ngOnInit(): void{
      this.gettimesheet();
    }
  
    private gettimesheet(){
 // timesheetDetails =null;
  //timesheetToUpdate: Timesheet=new Timesheet();
  this.timesheetService.getTimesheetsList().subscribe(data =>{
    this.timesheet=data
    console.log(data);
  });
}
}
    
