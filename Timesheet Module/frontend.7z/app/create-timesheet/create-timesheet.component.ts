import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Timesheet } from '../timesheet';
import { TimesheetService } from '../timesheet.service';

@Component({
  selector: 'app-create-timesheet',
  templateUrl: './create-timesheet.component.html',
  styleUrls: ['./create-timesheet.component.css']
})
export class CreateTimesheetComponent implements OnInit {

  timesheet: Timesheet = new Timesheet();
  constructor(private timesheetService: TimesheetService,
    private router: Router) { }

  ngOnInit(): void {
  }

  saveTimesheet(){
    this.timesheetService.createTimesheet(this.timesheet).subscribe(data =>{
      console.log(data);
      this.goToTimesheetList();
    },
    error => console.log(error));
  }

  goToTimesheetList(){
    this.router.navigate(['/timesheets']);
  }
  onSubmit(){
    console.log(this.timesheet);
    this.saveTimesheet();

  }

}
