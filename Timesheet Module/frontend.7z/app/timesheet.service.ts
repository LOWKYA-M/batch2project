import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Timesheet } from './timesheet';

@Injectable({
  providedIn: 'root'
})
export class TimesheetService {

  private baseURL ="http://localhost:8085/api/v1/timesheets";

  constructor(private httpClient: HttpClient) { }

  getTimesheetsList(): Observable<Timesheet[]>{
    return this.httpClient.get<Timesheet[]>(`${this.baseURL}`);
  }

  createTimesheet(timesheet: Timesheet): Observable<Object>{
    return this.httpClient.post(`${this.baseURL}`, timesheet);
  }

  getTimesheetById(empId: number): Observable<Timesheet>{
    return this.httpClient.get<Timesheet>(`${this.baseURL})/${empId}`);
  }

  updateTimesheet(empId: number, timesheet: Timesheet): Observable<Object>{
    return this.httpClient.put(`${this.baseURL}/${empId}`, timesheet);
  }

  deleteTimesheet(empId: number): Observable<Object>{
    return this.httpClient.delete(`${this.baseURL}/${empId}`);
  }
}
