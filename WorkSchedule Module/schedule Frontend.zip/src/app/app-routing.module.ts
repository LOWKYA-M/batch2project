import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { CreateEmployee1Component } from './create-employee1/create-employee1.component';
import { UpdateEmpComponent } from './update-emp/update-emp.component';

const routes: Routes = [
  {path:'employees',component:EmployeeListComponent},
  {path:'', redirectTo: 'employees', pathMatch: 'full'},
  {path: 'create-employee',component:CreateEmployee1Component},
  {path: 'update-emp/:empId', component: UpdateEmpComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
