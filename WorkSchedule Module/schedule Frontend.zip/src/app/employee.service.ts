import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  private baseURL="http://localhost:8083/api/v1/schedule";

  constructor(private HttpClient:HttpClient) { }

  getEmployeesList():Observable<Employee[]>{
    return this.HttpClient.get<Employee[]>(`${this.baseURL}`);
  }

  createEmployee(employee:Employee):Observable<object>{
    return this.HttpClient.post(`${this.baseURL}`,employee);
  }
  getEmployeeByEmpId(empId: number): Observable<Employee>{
    return this.HttpClient.get<Employee>(`${this.baseURL}/${empId}`);
  }
  updateEmp(empId: number, employee: Employee): Observable<Object>{
    return this.HttpClient.put(`${this.baseURL}/${empId}`, employee);
  }


  deleteEmployee(empId: number):Observable<object>{
    return this.HttpClient.delete(`${this.baseURL}/${empId}`);
  }
  }

