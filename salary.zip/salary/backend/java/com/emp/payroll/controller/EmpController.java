package com.emp.payroll.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.emp.payroll.model.Employee;
import com.emp.payroll.repository.EmpRepository;

@Repository
@CrossOrigin(origins ="*")
@RestController
@RequestMapping("/api/v1/")
public class EmpController {

	@Autowired
	private EmpRepository emprepository;
	
	@CrossOrigin(origins ="*")
	@GetMapping("/employee/{emailId}")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable String emailId)
	{
		//Employee employee = emprepository.findByEmailId(emailId);
		
		//System.out.println(employee.getEmailId());
		//System.out.println(emprepository);

		return (ResponseEntity<Employee>) emprepository.findByEmailId(emailId);
		//return emprepository.findByEmailId(emailId);
		
		//return "redirect:/admin/{empId}"; 
	}
	
	@PutMapping("/employee/{emailId}")
	public List<Employee> updateEmployee(@PathVariable String emailId, @RequestBody(required=false) Employee admin1)
	{
		List<Employee> employee = emprepository.findByEmailId(emailId);

		((Employee) employee).setEmpId(admin1.getEmpId());
		((Employee) employee).setfName(admin1.getfName());
		((Employee) employee).setlName(admin1.getlName());
		((Employee) employee).setDob(admin1.getDob());
		((Employee) employee).setGender(admin1.getGender());
		((Employee) employee).setStreet(admin1.getStreet());
		((Employee) employee).setLocation(admin1.getLocation());
		((Employee) employee).setCity(admin1.getCity());
		((Employee) employee).setState(admin1.getState());
		((Employee) employee).setPincode(admin1.getPincode());
		((Employee) employee).setMobNo(admin1.getMobNo());
		((Employee) employee).setEmailId(admin1.getEmailId());
		((Employee) employee).setPassword(admin1.getPassword());
		((Employee) employee).setdesignation(admin1.getdesignation());
		
		Employee updatedEmployee = emprepository.save(employee);
		return (List<Employee>) ResponseEntity.ok(updatedEmployee);
	}	
	
		
	}
