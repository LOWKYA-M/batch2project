package com.emp.payroll.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.emp.payroll.service.RegistrationService;
import com.emp.payroll.model.Employee;
import com.emp.payroll.repository.RegistrationRepository;

@RestController
public class RegistrationController {
	@Autowired
	private RegistrationService service;
	private RegistrationRepository regrepo;
	
	@PostMapping("/registeremp")
	@CrossOrigin(origins = "*")
	public Employee registerEmployee(@RequestBody Employee emp) throws Exception{
		String tempEmailId = emp.getEmailId();
		if(tempEmailId != null && !"".equals(tempEmailId))
		{
			Employee empobj = service.fetchEmpByEmailId(tempEmailId);
			if(empobj != null)
			{
				throw new Exception("Employee with "+tempEmailId+" is already exists");
			}
			
		}
		Employee empObj=null;
		empObj = service.saveUser(emp);
		return empObj;
	}
	
	@PostMapping("/emplogin")
	@CrossOrigin(origins = "*")
	public Employee loginEmp(@RequestBody Employee emp) throws Exception {
		String tempEmailId = emp.getEmailId();
		String tempPass=emp.getPassword();
		Employee empObj = null;
		if(tempEmailId != null && tempPass != null ) {
			empObj = service.fetchEmpByEmailIdandPassword(tempEmailId, tempPass);
			
		}
		if(empObj ==null) {
			throw new Exception("Bad  Credentials");
		}
			
		return empObj;
	
	}
	/*
	 valiadtion---forgot password
	 */
	@PutMapping("/forgotpasswordemp")
	@CrossOrigin(origins = "*")
	public Employee forgotpasswordemp(@RequestBody Employee emp) throws Exception {
		String tempEmailId = emp.getEmailId();
		String tempMobNo = emp.getMobNo();
		Employee empObj = null;
		if(tempEmailId != null && tempMobNo != null ) {
			empObj = service.fetchEmpByEmailIdandmobNo(tempEmailId, tempMobNo);		
		}
		if(empObj ==null) {
			throw new Exception("No Employee found with these credentials!");
		}
			
		return empObj;
	
	}
	
	
	@GetMapping("/{emailId}")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable String emailId)
	{
		Employee employee = service.fetchEmpByEmailId((String) emailId);
		return ResponseEntity.ok(employee);
		//return "redirect:/admin/{empId}"; 
	}
	
	@PutMapping("/epasswordreset/{emailId}")
	public ResponseEntity<Employee> updateEmpPassword(@PathVariable  String emailId, @RequestBody(required = false) Employee employee){
		Employee employeeForgot=service.fetchEmpByEmailId(emailId);
		{
			//employeeForgot.setEmailId(employee.getEmailId());
			//System.out.println(password);
			System.out.println(employee.getEmailId());

			employeeForgot.setPassword(employee.getPassword());
			
			Employee updatedEmployee = service.saveUser(employee);

			return ResponseEntity.ok(updatedEmployee);
		
			


	}
}
}