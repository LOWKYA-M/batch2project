import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CheckempdetailsComponent } from './checkempdetails/checkempdetails.component';
import { EmploginComponent } from './emplogin/emplogin.component';
import { EmpregistrationComponent } from './empregistration/empregistration.component';
import { LoginsuccsessComponent } from './loginsuccsess/loginsuccsess.component';
import { SalarylistComponent } from './salarylist/salarylist.component';
import { AddsalaryComponent } from './addsalary/addsalary.component';
import { EditsalaryComponent } from './editsalary/editsalary.component';
import { ViewsalaryComponent } from './viewsalary/viewsalary.component';

const routes: Routes = [
  {path:'emplogin',component:EmploginComponent},
  {path:'loginsuccsess',component:LoginsuccsessComponent},
  {path:'registeration',component:EmpregistrationComponent},
  {path:'checkempdetails',component:CheckempdetailsComponent},
  {path:'',component:SalarylistComponent},
  {path:'addsalary',component:AddsalaryComponent},
  {path:'salarylist',component:SalarylistComponent},
  {path:'editsalary',component:EditsalaryComponent},
  {path:'editsalary/:salId',component:EditsalaryComponent},
  {path:'viewsalary/:salId',component:ViewsalaryComponent},


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
