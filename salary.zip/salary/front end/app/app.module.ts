import { HttpClient, HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmploginComponent } from './emplogin/emplogin.component';
import { EmpregistrationComponent } from './empregistration/empregistration.component';
import { LoginsuccsessComponent } from './loginsuccsess/loginsuccsess.component';
import { EmpforgotpasswordComponent } from './empforgotpassword/empforgotpassword.component';
import { CheckempdetailsComponent } from './checkempdetails/checkempdetails.component';
import { AddsalaryComponent } from './addsalary/addsalary.component';
import { SalarylistComponent } from './salarylist/salarylist.component';
import { EditsalaryComponent } from './editsalary/editsalary.component';
import { ViewsalaryComponent } from './viewsalary/viewsalary.component';

@NgModule({
  declarations: [
    AppComponent,
    EmploginComponent,
    EmpregistrationComponent,
    LoginsuccsessComponent,
    EmpforgotpasswordComponent,
    CheckempdetailsComponent,
    AddsalaryComponent,
    SalarylistComponent,
    EditsalaryComponent,
    ViewsalaryComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
