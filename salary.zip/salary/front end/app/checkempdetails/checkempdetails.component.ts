import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Route, Router } from '@angular/router';
import { EmpRegistraionService } from '../emp-registraion.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-checkempdetails',
  templateUrl: './checkempdetails.component.html',
  styleUrls: ['./checkempdetails.component.css']
})
export class CheckempdetailsComponent implements OnInit {
  employee = new Employee();
  msg=''

  constructor(private _service: EmpRegistraionService, private _router: Router) { }

  ngOnInit() : void {

  }
  forgotPasswordcheck(){
    this._service.resetPasswordCheckEmp(this.employee).subscribe(
      data =>{ console.log("respnse recieved");
      this._router.navigate(['/'])
    },
      error => {
        console.log("exception occured");
       this.msg="Bad Credentia, please enter valid registerd emailid and mobile number";
      }
    )

}
}
