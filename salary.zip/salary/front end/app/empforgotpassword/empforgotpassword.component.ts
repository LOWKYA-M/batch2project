import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-empforgotpassword',
  templateUrl: './empforgotpassword.component.html',
  styleUrls: ['./empforgotpassword.component.css']
})
export class EmpforgotpasswordComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
