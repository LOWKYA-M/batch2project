import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Route, Router } from '@angular/router';
import { EmpRegistraionService } from '../emp-registraion.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-emplogin',
  templateUrl: './emplogin.component.html',
  styleUrls: ['./emplogin.component.css']
})
export class EmploginComponent implements OnInit {
   employee = new Employee();
   msg = '';
  constructor(private _service : EmpRegistraionService, private _router : Router) { }

  ngOnInit(): void {
  }
  loginEmp(){
    this._service.loginEmpRemote(this.employee).subscribe(
      data =>{ console.log("respnse recieved");
      this._router.navigate(['/loginsuccsess'])
    },
      error => {
        console.log("exception occured");
       this.msg="Bad Credentia, please enter valid emailid and password";
      }
    )

  }
  gotoregisteration(){
    this._router.navigate(['/registeration'])
  }

}
