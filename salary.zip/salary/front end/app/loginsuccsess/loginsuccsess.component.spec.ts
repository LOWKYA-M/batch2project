import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginsuccsessComponent } from './loginsuccsess.component';

describe('LoginsuccsessComponent', () => {
  let component: LoginsuccsessComponent;
  let fixture: ComponentFixture<LoginsuccsessComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoginsuccsessComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginsuccsessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
