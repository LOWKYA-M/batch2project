import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loginsuccsess',
  templateUrl: './loginsuccsess.component.html',
  styleUrls: ['./loginsuccsess.component.css']
})
export class LoginsuccsessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
