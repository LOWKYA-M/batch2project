import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
class Salary {
}



@Injectable({
  providedIn: 'root'
})
export class SalserviceService {

  constructor(private _http:HttpClient) { }

  fetchSalaryListFromRemote():Observable<any>{
   return this._http.get<any>("http://localhost:8081/getsalary")
  }
  addSalaryListFromRemote(salary :Salary):Observable<any>{
    return this._http.post<any>("http://localhost:8081/addsalary",salary)
   }


   updateSalaryToRemote(salary: Salary): Observable<any>{
    return this._http.post<any>('http://localhost:8081/editsalary',salary);
  }

  fetchSalaryByIdFromRemote(id: number): Observable<any> {
    return this._http.get<any>('http://localhost:8081/getsalarybyid/'+id);
  }

// deleteSalaryByIdFromRemote(id: number): Observable<any> {
//     return this._http.delete<any>('http://localhost:8081/deletesalary/'+id);
//   }

  deleteSalaryBdyIdFromRemote(id: number): Observable<any> {
    return this._http.delete<any>('http://localhost:8081/deletesalary/' + id);
  }

}
