import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Admin } from './admin';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  private baseURL = "http://localhost:8085/api/v1/admin";
  empId: any;
  
  constructor(private httpClient: HttpClient) { }

  // public findAll(): Observable<Admin[]> {
  //   return this.httpClient.get<Admin[]>(this.baseURL);
  // }

  getEmployeesList(): Observable<Admin[]>{
    return this.httpClient.get<Admin[]>(`${this.baseURL}`);
  }

  createEmployee(employee: Admin): Observable<Object>{
    return this.httpClient.post(`${this.baseURL}`, employee);
  }

  getEmployeeById(empId=this.empId): Observable<Admin>{
return this.httpClient.get<Admin>(`${this.baseURL}/${empId}`);
  }

  updateEmployee(empId: number, admin: Admin): Observable<Object>{
    return this.httpClient.put(`${this.baseURL}/${empId}`,admin);
  }

  deleteEmployee(empId: number): Observable<Object>{
    return this.httpClient.delete(`${this.baseURL}/${empId}`);
  }
}
