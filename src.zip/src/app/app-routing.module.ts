import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateEmployeeComponent } from './create-employee/create-employee.component';
import { EmploginComponent } from './emplogin/emplogin.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { EmpregistrationComponent } from './empregistration/empregistration.component';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';

const routes: Routes = [
  {path: 'Admins', component: EmployeeListComponent},
  {path: 'createemployee', component: CreateEmployeeComponent},
  {path:'', redirectTo: 'registeration', pathMatch: 'full'},
  {path:'updateemployee/:empId', component: UpdateEmployeeComponent},
  {path:'emplogin',component: EmploginComponent},
  {path:'loginsuccess',component:EmployeeListComponent},
  {path:'registeration',component:EmpregistrationComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
