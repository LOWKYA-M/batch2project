import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee } from './employee';
import {HttpClient} from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class EmpRegistraionService {

  constructor(private _http : HttpClient) { }

  public loginEmpRemote(employee:Employee):Observable<any>{
   return this._http.post<any>("http://localhost:8085/emplogin",employee)
  }
  public registerUserFromRemote(employee : Employee):Observable<any>{
    return this._http.post<any>("http://localhost:8085/registeremp",employee);
  }

}
