import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Admin } from '../admin';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  Admins : Admin[];
  constructor(private adminService: AdminService,
    private router: Router) { }
 
  ngOnInit(): void {

    this.getEmployees();
  }

  private getEmployees(){

    this.adminService.getEmployeesList().subscribe(data =>
      {
        this.Admins = data;
        
      });
  }

  updateEmployee(empId: number)
  {
    this.router.navigate(['updateemployee', empId]);
  }

  deleteEmployee(empId: number)
  {
    this.adminService.deleteEmployee(empId).subscribe(data => {
      console.log(data);
      this.getEmployees();
    })
  }
}
