package com.emp.payroll;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.annotation.Order;

import com.emp.payroll.model.Timesheet;
import com.emp.payroll.repository.TimesheetRepository;


@SpringBootTest
class AdmintimesheetApplicationTests {

	@Autowired
	TimesheetRepository tRepo;

	@Test
	@Order(1)
	public void testcreate() {
		Timesheet t = new Timesheet();
		t.setEmpId(2);
		t.setDate("3-03-2022");
		t.setInTime("9am");
		t.setBreakTime("1pm");
		t.setOutTime("6pm");
		t.setRegularTime("10");
		t.setOvertimeHours("2");
		t.setTotalHours("10");
		tRepo.save(t);
		assertNotNull(tRepo.findById(2).get());

	}

	@Test
	@Order(2)
	public void testReadAll() {
		List<Timesheet> list = (List<Timesheet>) tRepo.findAll();
		assertThat(list).size().isGreaterThan(0);

	}

	@Test
	@Order(3)
	public void testSingleProduct() {
		Timesheet timesheet = tRepo.findById(2).get();
		assertEquals("1pm", timesheet.getBreakTime());
	}

	@Test
	@Order(4)
	public void testUpdate() {
		Timesheet a = tRepo.findById(2).get();
		a.setBreakTime("2hr");
		tRepo.save(a);
		assertNotEquals("1pm", tRepo.findById(2).get().getBreakTime());
	}

	@Test
	@Order(5)
	public void testDelete() {
		tRepo.deleteById(1);
		assertThat(tRepo.existsById(1)).isFalse();
	}
}